
 String  getImgPath(String img,{String sux='.webp'}){
    return 'assets/images/$img$sux';
 }